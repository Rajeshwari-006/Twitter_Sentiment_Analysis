# SentimentX — Twitter Sentiment Analysis

A lightweight NLP-powered Twitter sentiment analyzer built with **Flask** and **pure Python** (no heavy ML deps).

## Features
- **Single tweet analysis** — sentiment label, confidence score, keyword extraction, hashtag/mention/emoji detection
- **Batch analysis** — analyze up to 20 tweets at once with a summary breakdown
- **NLP engine** — lexicon-based scoring with negation handling, intensifier amplification, and emoji scoring
- **Zero ML dependencies** — runs anywhere with just Flask

## Project Structure
```
sentiment-app/
├── app.py              # Flask backend + NLP engine
├── requirements.txt
└── templates/
    └── index.html      # Single-file frontend (HTML + CSS + JS)
```

## Setup & Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the server
python app.py
```

Then open **http://localhost:5000** in your browser.

## API Endpoints

### POST /analyze
Analyze a single tweet.
```json
// Request
{ "text": "I absolutely love this amazing product! 🎉" }

// Response
{
  "sentiment": "Positive",
  "emoji": "😊",
  "confidence": 87,
  "raw_score": 1.2,
  "stats": { "total_words": 7, "positive_words": 2, "hashtags": [], ... },
  "keywords": [{ "word": "love", "count": 1, "type": "positive" }, ...]
}
```

### POST /batch
Analyze multiple tweets (one per array item, max 20).
```json
// Request
{ "tweets": ["Tweet one...", "Tweet two...", "Tweet three..."] }

// Response
{
  "results": [...],
  "summary": { "total": 3, "positive": 2, "negative": 0, "neutral": 1, ... }
}
```

## NLP Algorithm

1. **Preprocessing** — strip URLs, @mentions, isolated `#`, lowercase
2. **Tokenization** — whitespace split
3. **Scoring** — iterate tokens:
   - Negators (`not`, `never`, `isn't` …) flip the sign multiplier
   - Intensifiers (`very`, `extremely` …) amplify by ×1.5
   - Positive/negative lexicon words add ±1 × current multiplier
4. **Emoji scoring** — 28 common emojis mapped to –3 … +3
5. **Normalisation** — score ÷ √(word_count) to reduce length bias
6. **Classification** — `norm > 0.4` → Positive, `< -0.4` → Negative, else Neutral
7. **Confidence** — sigmoid-mapped from absolute normalised score (50–100%)
