from flask import Flask, request, jsonify, render_template
import re
import math
from collections import Counter
from datetime import datetime

app = Flask(__name__)

POSITIVE_WORDS = {
    "love","amazing","great","awesome","fantastic","excellent","wonderful","best",
    "good","happy","joy","excited","brilliant","perfect","beautiful","nice",
    "incredible","outstanding","superb","terrific","delightful","grateful",
    "thankful","blessed","positive","winning","success","thrilled","pleased",
    "glad","fun","enjoy","enjoyed","helpful","inspiring","inspired","magnificent",
    "marvelous","splendid","fabulous","wow","yay","congrats","congratulations",
    "proud","genius","smart","innovative","revolutionary","breakthrough",
    "impressive","remarkable","flawless","elegant","smooth","fast","efficient",
    "reliable","trustworthy","honest","kind","generous","caring","supportive",
    "uplifting","refreshing","energetic","vibrant","lively","cheerful","hopeful",
    "optimistic","peaceful","calm","safe","secure","powerful","creative","passionate",
    "motivated","determined","brave","courageous","heroic","legendary","iconic",
    "stellar","phenomenal","extraordinary","divine","pure","genuine","authentic",
    "praiseworthy","spectacular","mind-blowing","jaw-dropping","heartwarming"
}

NEGATIVE_WORDS = {
    "hate","terrible","awful","horrible","bad","worst","disgusting","disappointed",
    "frustrating","annoying","useless","broken","failed","failure","wrong","stupid",
    "pathetic","ridiculous","sad","angry","upset","boring","dull","ugly","poor",
    "weak","slow","buggy","toxic","dangerous","harmful","corrupt","evil","scary",
    "fear","threat","problem","issue","bug","error","crash","lag","spam","scam",
    "fake","lie","liar","misleading","deceptive","unfair","biased","offensive",
    "rude","mean","cruel","harsh","bitter","depressing","hopeless","worthless",
    "pointless","waste","regret","apologize","mistake","dreadful","appalling",
    "catastrophic","disaster","nightmare","chaos","garbage","trash","junk",
    "miserable","painful","suffering","devastating","horrifying","shocking",
    "outrageous","unacceptable","irresponsible","reckless","negligent","abusive",
    "violent","aggressive","hostile","threatening","alarming","disgraceful"
}

INTENSIFIERS = {
    "very":1.5,"extremely":2.0,"absolutely":2.0,"totally":1.7,"completely":1.8,
    "so":1.4,"really":1.4,"super":1.6,"highly":1.5,"incredibly":1.9,
    "insanely":1.8,"ridiculously":1.5,"utterly":1.9,"deeply":1.6,"truly":1.5,
    "genuinely":1.4,"remarkably":1.7,"exceptionally":1.8,"outrageously":1.7,
    "overwhelmingly":1.8,"massively":1.6,"enormously":1.7,"tremendously":1.8
}

NEGATORS = {
    "not","no","never","isn't","aren't","wasn't","weren't","don't","doesn't",
    "didn't","can't","cannot","won't","wouldn't","shouldn't","couldn't","hardly",
    "barely","scarcely","neither","nor","nothing","nobody","nowhere","without"
}

DIMINISHERS = {
    "somewhat","slightly","fairly","rather","quite","kind","sort","little",
    "bit","mildly","moderately","partially","barely","almost","nearly"
}

EMOTION_LEXICON = {
    "happy":{"joy":3},"joy":{"joy":3},"excited":{"joy":2,"anticipation":2},
    "delightful":{"joy":3},"wonderful":{"joy":3},"love":{"joy":3,"trust":2},
    "amazing":{"joy":2},"fantastic":{"joy":3},"great":{"joy":2},
    "celebrate":{"joy":3},"yay":{"joy":3},"awesome":{"joy":2},
    "cheerful":{"joy":2},"bliss":{"joy":3},"ecstatic":{"joy":3},
    "trust":{"trust":3},"reliable":{"trust":3},"honest":{"trust":3},
    "safe":{"trust":2},"secure":{"trust":2},"genuine":{"trust":2},
    "authentic":{"trust":2},"loyal":{"trust":3},"faithful":{"trust":3},
    "fear":{"fear":3},"scary":{"fear":3},"terrified":{"fear":3},
    "afraid":{"fear":3},"anxious":{"fear":2,"sadness":1},
    "panic":{"fear":3},"horror":{"fear":3},"dread":{"fear":2},
    "worried":{"fear":2},"nervous":{"fear":2},"threat":{"fear":2},
    "surprised":{"surprise":3},"shocked":{"surprise":3},"wow":{"surprise":2,"joy":1},
    "unexpected":{"surprise":2},"astonished":{"surprise":3},"amazed":{"surprise":2},
    "sad":{"sadness":3},"crying":{"sadness":3},"heartbroken":{"sadness":3},
    "depressed":{"sadness":3},"miserable":{"sadness":3},"unhappy":{"sadness":2},
    "grief":{"sadness":3},"sorrow":{"sadness":3},"lonely":{"sadness":2},
    "hopeless":{"sadness":3},"devastated":{"sadness":3},
    "disgusting":{"disgust":3},"gross":{"disgust":3},"revolting":{"disgust":3},
    "horrible":{"disgust":2,"sadness":1},"awful":{"disgust":2},
    "nasty":{"disgust":2},"vile":{"disgust":3},"filthy":{"disgust":2},
    "angry":{"anger":3},"furious":{"anger":3},"hate":{"anger":3},
    "rage":{"anger":3},"mad":{"anger":2},"outraged":{"anger":3},
    "frustrated":{"anger":2},"irritated":{"anger":2},"annoyed":{"anger":2},
    "hostile":{"anger":3},"aggressive":{"anger":2},
    "hope":{"anticipation":2,"joy":1},"expect":{"anticipation":2},
    "anticipate":{"anticipation":3},"eager":{"anticipation":2,"joy":1},
    "curious":{"anticipation":2},"interested":{"anticipation":1},
}

EMOTION_COLORS = {
    "joy":"#f7c948","trust":"#22d3a5","fear":"#9333ea",
    "surprise":"#f97316","sadness":"#60a5fa","disgust":"#84cc16",
    "anger":"#f4456e","anticipation":"#fb923c"
}
EMOTION_EMOJIS = {
    "joy":"😄","trust":"🤝","fear":"😨","surprise":"😲",
    "sadness":"😢","disgust":"🤮","anger":"😡","anticipation":"🤩"
}

TOPICS = {
    "Technology":    ["tech","software","ai","app","code","data","server","algorithm","machine","digital","hardware","cpu","gpu","cloud","api","python","java","javascript","startup","saas","developer","programming","database","network","cybersecurity","blockchain","iot","automation"],
    "Politics":      ["government","president","election","vote","policy","law","senate","congress","democrat","republican","political","minister","parliament","rights","freedom","constitution","democracy","campaign","legislation","reform"],
    "Sports":        ["game","win","lose","team","player","score","match","tournament","champion","football","basketball","cricket","tennis","olympic","league","goal","stadium","athlete","coach","season"],
    "Entertainment": ["movie","film","music","album","concert","show","tv","celebrity","actor","singer","artist","netflix","spotify","award","series","episode","streaming","box","office","director"],
    "Health":        ["health","medicine","doctor","hospital","vaccine","virus","mental","wellness","fitness","diet","exercise","surgery","symptom","disease","treatment","therapy","patient","pharmacy","clinical","research"],
    "Business":      ["market","stock","economy","company","brand","profit","revenue","investment","startup","entrepreneur","finance","trade","shares","nasdaq","earnings","ceo","merger","acquisition","valuation","ipo"],
    "Environment":   ["climate","green","pollution","carbon","nature","forest","ocean","renewable","energy","sustainability","wildlife","planet","eco","solar","wind","emissions","drought","flood","biodiversity"],
    "Social":        ["people","community","society","culture","family","relationship","friend","social","media","news","viral","trend","hashtag","protest","movement","equality","justice","diversity","inclusion"],
}

SARCASM_PATTERNS = [
    r"\b(yeah right|sure sure|oh great|thanks a lot|brilliant job|wow just wow|as if|whatever|big deal|so original|totally normal|just perfect|oh wonderful)\b",
    r"(!!!|\.\.\.|--)",
    r"\b(totally|definitely|absolutely)\b.{0,30}\b(not|never|zero)\b",
    r"#(sarcasm|irony|notreally|surenot|surejan|ohreally)",
]

EMOJI_SCORES = {
    "😀":2,"😊":2,"😍":3,"🥰":3,"😁":2,"🎉":3,"❤️":3,"💯":2,"👍":2,
    "🔥":1,"✨":1,"🙌":2,"😭":-2,"😡":-3,"💔":-2,"👎":-2,"😤":-2,
    "😠":-2,"🤬":-3,"😢":-2,"😞":-2,"😒":-1,"🤮":-3,"💩":-2,"🤦":-1,
    "😑":-1,"😐":0,"🤔":0,"😶":0,"🥺":-1,"😳":0,"🤯":2,"🤩":3,
    "😎":2,"🤑":1,"😴":-1,"🤢":-2,"😱":-1,"🙄":-1,"😅":1,"😂":2,
    "🤣":2,"💪":2,"🎯":2,"🏆":3,"💡":1,"🚀":2,"⚡":1,"🌟":2,"⭐":2,
    "❌":-2,"✅":2,"⚠️":-1,"🔴":-1,"🟢":1
}

STOP_WORDS = {
    "the","a","an","is","are","was","were","be","been","being","have","has","had",
    "do","does","did","will","would","could","should","may","might","shall","must",
    "to","of","in","for","on","with","at","by","from","up","about","into","through",
    "during","before","after","above","below","between","out","off","over","under",
    "again","further","then","once","here","there","when","where","why","how","all",
    "both","each","few","more","most","other","some","such","no","nor","not","only",
    "same","so","than","too","very","just","but","and","or","if","as","what","which",
    "who","this","that","these","those","i","me","my","we","our","you","your","he",
    "she","it","they","them","their","its","his","her","rt","via","amp","gt","lt"
}

def preprocess(text):
    emojis   = [c for c in text if c in EMOJI_SCORES]
    clean    = re.sub(r"http\S+", "", text)
    mentions = re.findall(r"@(\w+)", clean)
    hashtags = re.findall(r"#(\w+)", clean)
    clean    = re.sub(r"@\w+|#\w+", "", clean)
    clean    = re.sub(r"[^a-zA-Z0-9'\s]", " ", clean)
    tokens   = clean.lower().split()
    return tokens, emojis, hashtags, mentions

def compute_sentiment(tokens, emojis):
    score = 0.0
    negated = False
    intens  = 1.0
    dimin   = 1.0
    contribs = []

    for t in tokens:
        if t in NEGATORS:
            negated = True
            continue
        if t in INTENSIFIERS:
            intens *= INTENSIFIERS[t]
            continue
        if t in DIMINISHERS:
            dimin *= 0.5
            continue
        w = 1.0 if t in POSITIVE_WORDS else (-1.0 if t in NEGATIVE_WORDS else 0.0)
        if w != 0:
            final = w * intens * dimin * (-0.8 if negated else 1.0)
            score += final
            contribs.append({"word":t,"contribution":round(final,2),
                              "type":"positive" if w > 0 else "negative"})
            negated = False; intens = 1.0; dimin = 1.0

    for e in emojis:
        score += EMOJI_SCORES.get(e, 0)
    return score, contribs

def classify(score, total_words):
    norm = score / max(math.sqrt(max(total_words, 1)), 1)
    if   norm >  0.6: label, em = "Very Positive", "🤩"
    elif norm >  0.2: label, em = "Positive",      "😊"
    elif norm < -0.6: label, em = "Very Negative",  "😤"
    elif norm < -0.2: label, em = "Negative",       "😡"
    else:             label, em = "Neutral",         "😐"
    confidence = min(99, int(40 + abs(norm) * 150))
    valence    = round(max(-1.0, min(1.0, norm / 2.0)), 3)
    return label, em, confidence, norm, valence

def detect_emotions(tokens):
    scores = {e: 0.0 for e in EMOTION_COLORS}
    for t in tokens:
        if t in EMOTION_LEXICON:
            for em, w in EMOTION_LEXICON[t].items():
                scores[em] += w
    total = sum(scores.values()) or 1
    ranked = sorted(scores.items(), key=lambda x: -x[1])
    return [{"emotion":e,"score":round(s,2),"pct":round(s/total*100),
             "color":EMOTION_COLORS[e],"emoji":EMOTION_EMOJIS[e]}
            for e,s in ranked if s > 0][:6]

def detect_topic(tokens, hashtags):
    combined = tokens + [h.lower() for h in hashtags]
    topic_scores = {}
    for topic, seeds in TOPICS.items():
        s = sum(1 for t in combined if t in seeds)
        if s: topic_scores[topic] = s
    return max(topic_scores, key=topic_scores.get) if topic_scores else "General"

def detect_sarcasm(text):
    text_l = text.lower()
    signals = []
    for p in SARCASM_PATTERNS:
        if re.search(p, text_l): signals.append(p[:20])
    pos_c = sum(1 for w in text_l.split() if w in POSITIVE_WORDS)
    neg_c = sum(1 for w in text_l.split() if w in NEGATIVE_WORDS)
    if pos_c > 0 and neg_c > 0 and abs(pos_c - neg_c) <= 1:
        signals.append("mixed_contrast")
    if len(re.findall(r"\b[A-Z]{3,}\b", text)) >= 2:
        signals.append("caps_emphasis")
    if text.count("!") >= 3:
        signals.append("excessive_exclamation")
    prob = min(95, len(signals) * 28)
    return {"probability": prob, "signals": len(signals), "detected": prob > 40}

def compute_subjectivity(tokens):
    subj_words = {"think","believe","feel","opinion","seems","looks","appears",
                  "probably","maybe","perhaps","might","definitely","certainly",
                  "absolutely","clearly","obviously","allegedly","reportedly"}
    obj_words  = {"study","research","data","report","according","statistics",
                  "percent","million","billion","fact","evidence","confirmed"}
    s = sum(1 for t in tokens if t in subj_words)
    o = sum(1 for t in tokens if t in obj_words)
    score = round(s / max(s+o, 1) * 100)
    return {"score": score, "label": "Subjective" if score > 50 else "Objective"}

def compute_readability(tokens, text):
    sentences   = max(1, len(re.findall(r'[.!?]+', text)))
    words       = len(tokens)
    avg_len     = sum(len(t) for t in tokens) / max(words, 1)
    wps         = words / sentences
    fk          = max(0, min(100, int(100 - wps * 2 - avg_len * 3)))
    level       = "Easy" if fk >= 70 else ("Medium" if fk >= 45 else "Complex")
    return {"score":fk,"level":level,
            "avg_word_len":round(avg_len,1),"words_per_sentence":round(wps,1)}

def tfidf_keywords(tokens):
    filtered = [t for t in tokens if t not in STOP_WORDS and len(t) > 2]
    freq = Counter(filtered)
    total = len(filtered) or 1
    kw = []
    for word, count in freq.most_common(20):
        tf  = count / total
        idf = math.log(total / count + 1)
        wtype = "positive" if word in POSITIVE_WORDS else ("negative" if word in NEGATIVE_WORDS else "neutral")
        kw.append({"word":word,"count":count,"tfidf":round(tf*idf,4),"type":wtype})
    kw.sort(key=lambda x: -x["tfidf"])
    return kw[:12]

def compute_tone(tokens, sentiment_label, sarcasm):
    ts = set(tokens)
    tones = []
    if any(t in ts for t in ["why","how","what","who","when","where"]): tones.append("Inquisitive")
    if any(t in ts for t in ["please","help","need","want","request","hope"]):  tones.append("Requesting")
    if any(t in ts for t in ["should","must","required","necessary","have"]): tones.append("Assertive")
    if any(t in ts for t in ["lol","haha","funny","hilarious","lmao","rofl"]): tones.append("Humorous")
    if sarcasm["detected"]: tones.append("Sarcastic")
    if "Positive" in sentiment_label: tones.append("Enthusiastic")
    if "Negative" in sentiment_label: tones.append("Critical")
    if not tones: tones.append("Informative")
    return tones[:4]

def word_cloud_data(tokens):
    filtered = [t for t in tokens if t not in STOP_WORDS and len(t) > 2]
    freq = Counter(filtered)
    max_f = freq.most_common(1)[0][1] if freq else 1
    return [{"word":w,"count":c,"size":round(12 + (c/max_f)*36),
             "type":"positive" if w in POSITIVE_WORDS else ("negative" if w in NEGATIVE_WORDS else "neutral")}
            for w,c in freq.most_common(25)]

analysis_history = []

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify({"error": "No text provided"}), 400

    tokens, emojis, hashtags, mentions = preprocess(text)
    score, contribs = compute_sentiment(tokens, emojis)
    label, em, confidence, norm, valence = classify(score, len(tokens))

    result = {
        "sentiment":    label,
        "emoji":        em,
        "confidence":   confidence,
        "valence":      valence,
        "raw_score":    round(norm, 3),
        "topic":        detect_topic(tokens, hashtags),
        "tones":        compute_tone(tokens, label, detect_sarcasm(text)),
        "sarcasm":      detect_sarcasm(text),
        "subjectivity": compute_subjectivity(tokens),
        "readability":  compute_readability(tokens, text),
        "emotions":     detect_emotions(tokens),
        "keywords":     tfidf_keywords(tokens),
        "word_cloud":   word_cloud_data(tokens),
        "contributions":contribs[:10],
        "stats": {
            "total_words":    len(tokens),
            "unique_words":   len(set(tokens)),
            "positive_words": sum(1 for t in tokens if t in POSITIVE_WORDS),
            "negative_words": sum(1 for t in tokens if t in NEGATIVE_WORDS),
            "hashtags":       hashtags,
            "mentions":       mentions,
            "emojis":         emojis,
            "char_count":     len(text),
            "sentence_count": max(1, len(re.findall(r'[.!?]+', text))),
        },
        "text":      text,
        "timestamp": datetime.now().isoformat()
    }

    analysis_history.append({
        "text": text[:80], "sentiment": label,
        "confidence": confidence, "valence": valence,
        "timestamp": result["timestamp"]
    })
    if len(analysis_history) > 50:
        analysis_history.pop(0)

    return jsonify(result)


@app.route("/batch", methods=["POST"])
def batch():
    data   = request.get_json()
    tweets = data.get("tweets", [])
    if not tweets:
        return jsonify({"error": "No tweets provided"}), 400

    results = []
    counts  = {"Very Positive":0,"Positive":0,"Neutral":0,"Negative":0,"Very Negative":0}
    val_sum = 0
    agg_emo = {e: 0.0 for e in EMOTION_COLORS}

    for tweet in tweets[:30]:
        tokens, emojis, hashtags, _ = preprocess(tweet)
        score, _ = compute_sentiment(tokens, emojis)
        label, em, conf, norm, valence = classify(score, len(tokens))
        emotions = detect_emotions(tokens)
        sarcasm  = detect_sarcasm(tweet)
        counts[label] = counts.get(label, 0) + 1
        val_sum += valence
        for e in emotions:
            agg_emo[e["emotion"]] += e["score"]
        results.append({
            "text": tweet[:140], "sentiment": label, "emoji": em,
            "confidence": conf, "valence": valence,
            "topic": detect_topic(tokens, hashtags),
            "sarcasm_prob": sarcasm["probability"],
        })

    total = len(results)
    avg_v = round(val_sum / total, 3) if total else 0
    top_em = sorted(agg_emo.items(), key=lambda x: -x[1])[:4]

    return jsonify({
        "results": results,
        "summary": {
            "total": total,
            "counts": counts,
            "avg_valence": avg_v,
            "overall_mood": ("Positive" if avg_v > 0.1 else ("Negative" if avg_v < -0.1 else "Neutral")),
            "top_emotions": [{"emotion":e,"score":round(s,2),
                               "emoji":EMOTION_EMOJIS[e],"color":EMOTION_COLORS[e]}
                              for e,s in top_em if s > 0],
        }
    })


@app.route("/history", methods=["GET"])
def history():
    return jsonify({"history": list(reversed(analysis_history[-20:]))})


@app.route("/compare", methods=["POST"])
def compare():
    data  = request.get_json()
    texts = data.get("texts", [])
    if len(texts) < 2:
        return jsonify({"error": "Provide at least 2 texts"}), 400
    out = []
    for text in texts[:4]:
        tokens, emojis, hashtags, _ = preprocess(text)
        score, _ = compute_sentiment(tokens, emojis)
        label, em, conf, norm, valence = classify(score, len(tokens))
        emotions = detect_emotions(tokens)
        out.append({"text": text[:100], "sentiment": label, "emoji": em,
                    "confidence": conf, "valence": valence,
                    "top_emotion": emotions[0] if emotions else None})
    return jsonify({"comparisons": out})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
